﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP2_LE2
{
    public partial class TicketingForm : Form
    {
        Label lblHelloWorld;
        Label lblDescription;
        Button btnHome;
        Button btnCinema;
        Button btnAbout;
        Button btnAccount;

        public TicketingForm()
        {
            InitializeComponent();
            this.Text = "Ticketing";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.ClientSize = new System.Drawing.Size(500, 300);

            
            lblHelloWorld = new Label
            {
                Text = "Hello World!",
                Font = new System.Drawing.Font("Arial", 20),
                AutoSize = true
            };
            Controls.Add(lblHelloWorld);

            lblDescription = new Label
            {
                Text = "This page will allow users to book tickets for movies.",
                AutoSize = true,
                MaximumSize = new System.Drawing.Size(400, 0)
            };
            Controls.Add(lblDescription);

            
            btnHome = new Button
            {
                Text = "Home",
                AutoSize = true
            };
            btnHome.Click += (sender, e) => { new HomeForm().Show(); this.Hide(); };
            Controls.Add(btnHome);

            btnCinema = new Button
            {
                Text = "Cinema",
                AutoSize = true
            };
            btnCinema.Click += (sender, e) => { new CinemaForm().Show(); this.Hide(); };
            Controls.Add(btnCinema);

            btnAbout = new Button
            {
                Text = "About",
                AutoSize = true
            };
            btnAbout.Click += (sender, e) => { new AboutForm().Show(); this.Hide(); };
            Controls.Add(btnAbout);

            btnAccount = new Button
            {
                Text = "Account",
                AutoSize = true
            };
            btnAccount.Click += (sender, e) => { new AccountForm().Show(); this.Hide(); };
            Controls.Add(btnAccount);

            
            this.Load += TicketingForm_Load;
            this.Resize += TicketingForm_Resize;
        }

        private void TicketingForm_Load(object sender, EventArgs e)
        {
            CenterControls();
        }

        private void TicketingForm_Resize(object sender, EventArgs e)
        {
            CenterControls();
        }

        private void CenterControls()
        {
            
            lblHelloWorld.Location = new System.Drawing.Point(
                (this.ClientSize.Width - lblHelloWorld.Width) / 2, 50);

            
            lblDescription.Location = new System.Drawing.Point(
                (this.ClientSize.Width - lblDescription.Width) / 2, lblHelloWorld.Bottom + 10);

            
            int spacing = 10;
            int totalButtonsWidth =
                btnHome.Width + btnCinema.Width + btnAbout.Width + btnAccount.Width + (3 * spacing);

            int startX = (this.ClientSize.Width - totalButtonsWidth) / 2;
            int buttonY = lblDescription.Bottom + 20;

            btnHome.Location = new System.Drawing.Point(startX, buttonY);
            btnCinema.Location = new System.Drawing.Point(btnHome.Right + spacing, buttonY);
            btnAbout.Location = new System.Drawing.Point(btnCinema.Right + spacing, buttonY);
            btnAccount.Location = new System.Drawing.Point(btnAbout.Right + spacing, buttonY);
        }
    }
}
