﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP2_LE2
{
    public partial class CinemaForm : Form
    {
        Label lblHelloWorld;
        Label lblDescription;
        Button btnHome;
        Button btnTicketing;
        Button btnAbout;
        Button btnAccount;

        public CinemaForm()
        {
            InitializeComponent();
            this.Text = "Cinema";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.ClientSize = new System.Drawing.Size(500, 300);

            lblHelloWorld = new Label
            {
                Text = "Hello World!",
                Font = new System.Drawing.Font("Arial", 20),
                AutoSize = true
            };
            Controls.Add(lblHelloWorld);

            lblDescription = new Label
            {
                Text = "This page will display a list of available movies along with their showtimes. Browse through the latest releases and select your preferred showtime.",
                AutoSize = true,
                MaximumSize = new System.Drawing.Size(400, 0)
            };
            Controls.Add(lblDescription);

            btnHome = new Button
            {
                Text = "Home",
                AutoSize = true
            };
            btnHome.Click += (sender, e) => { new HomeForm().Show(); this.Hide(); };
            Controls.Add(btnHome);

            btnTicketing = new Button
            {
                Text = "Ticketing",
                AutoSize = true
            };
            btnTicketing.Click += (sender, e) => { new TicketingForm().Show(); this.Hide(); };
            Controls.Add(btnTicketing);

            btnAbout = new Button
            {
                Text = "About",
                AutoSize = true
            };
            btnAbout.Click += (sender, e) => { new AboutForm().Show(); this.Hide(); };
            Controls.Add(btnAbout);

            btnAccount = new Button
            {
                Text = "Account",
                AutoSize = true
            };
            btnAccount.Click += (sender, e) => { new AccountForm().Show(); this.Hide(); };
            Controls.Add(btnAccount);

            this.Load += CinemaForm_Load;
            this.Resize += CinemaForm_Resize;
        }

        private void CinemaForm_Load(object sender, EventArgs e)
        {
            CenterControls();
        }

        private void CinemaForm_Resize(object sender, EventArgs e)
        {
            CenterControls();
        }

        private void CenterControls()
        {
            lblHelloWorld.Location = new System.Drawing.Point(
                (this.ClientSize.Width - lblHelloWorld.Width) / 2, 50);

            lblDescription.Location = new System.Drawing.Point(
                (this.ClientSize.Width - lblDescription.Width) / 2, lblHelloWorld.Bottom + 10);

            int spacing = 10;
            int totalButtonsWidth =
                btnHome.Width + btnTicketing.Width + btnAbout.Width + btnAccount.Width + (3 * spacing);

            int startX = (this.ClientSize.Width - totalButtonsWidth) / 2;
            int buttonY = lblDescription.Bottom + 20;

            btnHome.Location = new System.Drawing.Point(startX, buttonY);
            btnTicketing.Location = new System.Drawing.Point(btnHome.Right + spacing, buttonY);
            btnAbout.Location = new System.Drawing.Point(btnTicketing.Right + spacing, buttonY);
            btnAccount.Location = new System.Drawing.Point(btnAbout.Right + spacing, buttonY);
        }
    }
}
